/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
  "201": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"N New Jersey: Jersey City, Hackensack (see split973, overlay551)"
  },
  "202": {
    "Region":"DC",
    "TimezoneOffset":"-5",
    "Description":"Washington, D.C."
  },
  "203": {
    "Region":"CT",
    "TimezoneOffset":"-5",
    "Description":"Connecticut: Fairfield County and New Haven County; Bridgeport, New Haven (see860)"
  },
  "204": {
    "Region":"MB",
    "TimezoneOffset":"-6",
    "Description":"Canada: Manitoba (see overlay431)"
  },
  "205": {
    "Region":"AL",
    "TimezoneOffset":"-6",
    "Description":"Central Alabama (including Birmingham; excludes the southeastern corner of Alabama and the deep south; see splits256and334)"
  },
  "206": {
    "Region":"WA",
    "TimezoneOffset":"-8",
    "Description":"W Washington state: Seattle and Bainbridge Island (see splits253,360,425; overlay564)"
  },
  "207": {
    "Region":"ME",
    "TimezoneOffset":"-5",
    "Description":"Maine"
  },
  "208": {
    "Region":"ID",
    "TimezoneOffset":"0.875",
    "Description":"Idaho"
  },
  "209": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Cent. California: Stockton (see split559)"
  },
  "210": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"S Texas: San Antonio (see also splits830,956)"
  },
  "211": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Local community info / referral services"
  },
  "212": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York City, New York (Manhattan; see646,718)"
  },
  "213": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: Los Angeles (see310,323,626,818)"
  },
  "214": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Dallas Metro (overlays469/972)"
  },
  "215": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"SE Pennsylvania: Philadelphia (see overlays267)"
  },
  "216": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"Cleveland (see splits330,440)"
  },
  "217": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Cent. Illinois: Springfield"
  },
  "218": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"N Minnesota: Duluth"
  },
  "219": {
    "Region":"IN",
    "TimezoneOffset":"1.2",
    "Description":"NW Indiana: Gary (see split574,260)"
  },
  "220": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"SE and Central Ohio (outside Columbus; overlaid on740)"
  },
  "224": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Northern NE Illinois: Evanston, Waukegan, Northbrook (overlay on847, eff 1/5/02)"
  },
  "225": {
    "Region":"LA",
    "TimezoneOffset":"-6",
    "Description":"Louisiana: Baton Rouge, New Roads, Donaldsonville, Albany, Gonzales, Greensburg, Plaquemine, Vacherie (split from504)"
  },
  "226": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: SW Ontario: Windsor (overlays519,548)"
  },
  "228": {
    "Region":"MS",
    "TimezoneOffset":"-6",
    "Description":"S Mississippi (coastal areas, Biloxi, Gulfport; split from601)"
  },
  "229": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"SW Georgia: Albany (split from912; see also478; perm 8/1/00)"
  },
  "231": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"W Michigan: Northwestern portion of lower Peninsula; Traverse City, Muskegon, Cheboygan, Alanson"
  },
  "234": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"NE Ohio: Canton, Akron (overlaid on330; perm 10/30/00)"
  },
  "236": {
    "Region":"BC",
    "TimezoneOffset":"1.142857143",
    "Description":"Canada: British Columbia (see250,604)"
  },
  "239": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida (Lee, Collier, and Monroe Counties, excl the Keys; see305; eff 3/11/02; mand 3/11/03)"
  },
  "240": {
    "Region":"MD",
    "TimezoneOffset":"-5",
    "Description":"W Maryland: Silver Spring, Frederick, Gaithersburg (overlay, see301)"
  },
  "242": {
    "Region":"--",
    "TimezoneOffset":"-5",
    "Description":"Bahamas"
  },
  "246": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Barbados"
  },
  "248": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"Michigan: Oakland County, Pontiac (split from810; see overlay947)"
  },
  "250": {
    "Region":"BC",
    "TimezoneOffset":"1.142857143",
    "Description":"Canada: British Columbia (see236,604)"
  },
  "251": {
    "Region":"AL",
    "TimezoneOffset":"-6",
    "Description":"S Alabama: Mobile and coastal areas, Jackson, Evergreen, Monroeville (split from334, eff 6/18/01; see also205,256)"
  },
  "252": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"E North Carolina (Rocky Mount; split from919)"
  },
  "253": {
    "Region":"WA",
    "TimezoneOffset":"-8",
    "Description":"Washington: South Tier - Tacoma, Federal Way (split from206, see also425; overlay564)"
  },
  "254": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Central Texas (Waco, Stephenville; split, see817,940)"
  },
  "256": {
    "Region":"AL",
    "TimezoneOffset":"-6",
    "Description":"E and N Alabama (Huntsville, Florence, Gadsden; split from205; see also334)"
  },
  "260": {
    "Region":"IN",
    "TimezoneOffset":"-5",
    "Description":"NE Indiana: Fort Wayne (see219)"
  },
  "262": {
    "Region":"WI",
    "TimezoneOffset":"-6",
    "Description":"SE Wisconsin: counties of Kenosha, Ozaukee, Racine, Walworth, Washington, Waukesha (split from414)"
  },
  "264": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Anguilla (split from809)"
  },
  "267": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"SE Pennsylvania: Philadelphia (see215)"
  },
  "268": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Antigua and Barbuda (split from809)"
  },
  "269": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"SW Michigan: Kalamazoo, Saugatuck, Hastings, Battle Creek, Sturgis to Lake Michigan (split from616)"
  },
  "270": {
    "Region":"KY",
    "TimezoneOffset":"-6",
    "Description":"W Kentucky: Bowling Green, Paducah (split from502)"
  },
  "272": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"NE and N Central Pennsylvania: Wilkes-Barre, Scranton (see717; overlaid on570)"
  },
  "276": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"S and SW Virginia: Bristol, Stuart, Martinsville (split from540; perm 9/1/01, mand 3/16/02)"
  },
  "278": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"Michigan (overlaid on734, SUSPENDED)"
  },
  "281": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Houston Metro (split713; overlay832)"
  },
  "283": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"SW Ohio: Cincinnati (cancelled: overlaid on513)"
  },
  "284": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"British Virgin Islands (split from809)"
  },
  "289": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: S Cent. Ontario: Greater Toronto Area -- Durham, Halton, Hamilton-Wentworth, Niagara, Peel, York, and southern Simcoe County (excluding Toronto -- overlaid on905)"
  },
  "301": {
    "Region":"MD",
    "TimezoneOffset":"-5",
    "Description":"W Maryland: Silver Spring, Frederick, Camp Springs, Prince George's County (see240)"
  },
  "302": {
    "Region":"DE",
    "TimezoneOffset":"-5",
    "Description":"Delaware"
  },
  "303": {
    "Region":"CO",
    "TimezoneOffset":"-7",
    "Description":"Central Colorado: Denver (see970, also720overlay)"
  },
  "304": {
    "Region":"WV",
    "TimezoneOffset":"-5",
    "Description":"West Virginia (see overlay681)"
  },
  "305": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"SE Florida: Miami, the Keys (see786,954;239)"
  },
  "306": {
    "Region":"SK",
    "TimezoneOffset":"-6/-7*",
    "Description":"Canada: Saskatchewan (see overlay639)"
  },
  "307": {
    "Region":"WY",
    "TimezoneOffset":"-7",
    "Description":"Wyoming"
  },
  "308": {
    "Region":"NE",
    "TimezoneOffset":"0.857142857",
    "Description":"W Nebraska: North Platte"
  },
  "309": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"W Cent. Illinois: Peoria"
  },
  "310": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: Beverly Hills, West Hollywood, West Los Angeles (see split562; overlay424)"
  },
  "311": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Reserved for special applications"
  },
  "312": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Illinois: Chicago (downtown only -- in the loop; see773; overlay872)"
  },
  "313": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"Michigan: Detroit and suburbs (see734, overlay679)"
  },
  "314": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"SE Missouri: St Louis city and parts of the metro area only (see573,636, overlay557)"
  },
  "315": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"N Cent. New York: Syracuse"
  },
  "316": {
    "Region":"KS",
    "TimezoneOffset":"-6",
    "Description":"S Kansas: Wichita (see split620)"
  },
  "317": {
    "Region":"IN",
    "TimezoneOffset":"-5",
    "Description":"Cent. Indiana: Indianapolis (see765)"
  },
  "318": {
    "Region":"LA",
    "TimezoneOffset":"-6",
    "Description":"N Louisiana: Shreveport, Ruston, Monroe, Alexandria (see split337)"
  },
  "319": {
    "Region":"IA",
    "TimezoneOffset":"-6",
    "Description":"E Iowa: Cedar Rapids (see split563)"
  },
  "320": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"Cent. Minnesota: Saint Cloud (rural Minn, excl St. Paul/Minneapolis)"
  },
  "321": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida: Brevard County, Cape Canaveral area; Metro Orlando (split from407)"
  },
  "323": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: Los Angeles (outside downtown: Hollywood; split from213)"
  },
  "325": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Central Texas: Abilene, Sweetwater, Snyder, San Angelo (split from915)"
  },
  "330": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"NE Ohio: Akron, Canton, Youngstown; Mahoning County, parts of Trumbull/Warren counties (see splits216,440, overlay234)"
  },
  "331": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"W NE Illinois, western suburbs of Chicago (part of what used to be708; overlaid on630; eff 7/07)"
  },
  "334": {
    "Region":"AL",
    "TimezoneOffset":"-6",
    "Description":"S Alabama: Auburn/Opelika, Montgomery and coastal areas (part of what used to be205; see also256, split251)"
  },
  "336": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"Cent. North Carolina: Greensboro, Winston-Salem, High Point (split from910)"
  },
  "337": {
    "Region":"LA",
    "TimezoneOffset":"-6",
    "Description":"SW Louisiana: Lake Charles, Lafayette (see split318)"
  },
  "339": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Massachusetts: Boston suburbs, to the south and west (see splits617,508; overlaid on781, eff 5/2/01)"
  },
  "340": {
    "Region":"VI",
    "TimezoneOffset":"-4*",
    "Description":"US Virgin Islands (see also809)"
  },
  "341": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"(overlay on510; SUSPENDED)"
  },
  "343": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: SE Ontario: Ottawa (overlaid on613)"
  },
  "345": {
    "Region":"--",
    "TimezoneOffset":"-5",
    "Description":"Cayman Islands"
  },
  "347": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York (overlay for718: NYC area, except Manhattan)"
  },
  "351": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Massachusetts: north of Boston to NH,508, and781(overlaid on978, eff 4/2/01)"
  },
  "352": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida: Gainesville area, Ocala, Crystal River (split from904)"
  },
  "360": {
    "Region":"WA",
    "TimezoneOffset":"-8",
    "Description":"W Washington State: Olympia, Bellingham (area circling206,253, and425; split from206; see overlay564)"
  },
  "361": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"S Texas: Corpus Christi (split from512; eff 2/13/99)"
  },
  "365": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: S Cent. Ontario: Greater Toronto Area -- Durham, Halton, Hamilton-Wentworth, Niagara, Peel, York, and southern Simcoe County (overlaid on905)"
  },
  "369": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Solano County (perm 12/2/00, mand 6/2/01)"
  },
  "380": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"Ohio: Columbus (overlaid on614; assigned but not in use)"
  },
  "385": {
    "Region":"UT",
    "TimezoneOffset":"-7",
    "Description":"Utah: Salt Lake City Metro (split from801, eff 3/30/02 POSTPONED; see also435)"
  },
  "386": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"N central Florida: Lake City (split from904, perm 2/15/01, mand 11/5/01)"
  },
  "401": {
    "Region":"RI",
    "TimezoneOffset":"-5",
    "Description":"Rhode Island"
  },
  "402": {
    "Region":"NE",
    "TimezoneOffset":"-6",
    "Description":"E Nebraska: Omaha, Lincoln"
  },
  "403": {
    "Region":"AB",
    "TimezoneOffset":"-7",
    "Description":"Canada: Southern Alberta (see780,825,867)"
  },
  "404": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"N Georgia: Atlanta and suburbs (see overlay678, split770)"
  },
  "405": {
    "Region":"OK",
    "TimezoneOffset":"-6",
    "Description":"W Oklahoma: Oklahoma City (see580)"
  },
  "406": {
    "Region":"MT",
    "TimezoneOffset":"-7",
    "Description":"Montana"
  },
  "407": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Central Florida: Metro Orlando (see overlay689, eff 7/02; split321)"
  },
  "408": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Cent. Coastal California: San Jose (see overlay669)"
  },
  "409": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"SE Texas: Galveston, Port Arthur, Beaumont (splits936,979)"
  },
  "410": {
    "Region":"MD",
    "TimezoneOffset":"-5",
    "Description":"E Maryland: Baltimore, Annapolis, Chesapeake Bay area, Ocean City (see443)"
  },
  "411": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Reserved for special applications"
  },
  "412": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"W Pennsylvania: Pittsburgh (see split724, overlay878)"
  },
  "413": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"W Massachusetts: Springfield"
  },
  "414": {
    "Region":"WI",
    "TimezoneOffset":"-6",
    "Description":"SE Wisconsin: Milwaukee County (see splits920,262)"
  },
  "415": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: San Francisco County and Marin County on the north side of the Golden Gate Bridge, extending north to Sonoma County (see650split;628overlay, eff 2/2015)"
  },
  "416": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: S Cent. Ontario: Toronto (see overlays437,647)"
  },
  "417": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"SW Missouri: Springfield"
  },
  "418": {
    "Region":"QC",
    "TimezoneOffset":"1.25",
    "Description":"Canada: NE Quebec: Quebec (see overlay581)"
  },
  "419": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"NW Ohio: Toledo (see overlay567, perm 1/1/02)"
  },
  "423": {
    "Region":"TN",
    "TimezoneOffset":"-5",
    "Description":"E Tennessee, except Knoxville metro area: Chattanooga, Bristol, Johnson City, Kingsport, Greeneville (see split865; part of what used to be615)"
  },
  "424": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: Los Angeles (see split562; overlaid on310mand 7/26/06)"
  },
  "425": {
    "Region":"WA",
    "TimezoneOffset":"-8",
    "Description":"Washington: North Tier - Everett, Bellevue (split from206, see also253; overlay564)"
  },
  "430": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"NE Texas: Tyler (overlaid on903, eff 7/20/02)"
  },
  "431": {
    "Region":"MB",
    "TimezoneOffset":"-6",
    "Description":"Canada: Manitoba (overlaid on204; eff 11/12)"
  },
  "432": {
    "Region":"TX",
    "TimezoneOffset":"1.166666667",
    "Description":"W Texas: Big Spring, Midland, Odessa (split from915, eff 4/5/03)"
  },
  "434": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"E Virginia: Charlottesville, Lynchburg, Danville, South Boston, and Emporia (split from804, eff 6/1/01; see also757)"
  },
  "435": {
    "Region":"UT",
    "TimezoneOffset":"-7",
    "Description":"Rural Utah outside Salt Lake City metro (see split801)"
  },
  "437": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: S Cent. Ontario: Toronto (overlaid on416)"
  },
  "438": {
    "Region":"QC",
    "TimezoneOffset":"-5",
    "Description":"Canada: SW Quebec: Montreal city (overlaid on514, [delayed until 6/06] eff 10/10/03, mand 2/7/04)"
  },
  "440": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"Ohio: Cleveland metro area, excluding Cleveland (split from216, see also330)"
  },
  "441": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Bermuda (part of what used to be809)"
  },
  "442": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Far north suburbs of San Diego (Oceanside, Escondido; overlaid on760)"
  },
  "443": {
    "Region":"MD",
    "TimezoneOffset":"-5",
    "Description":"E Maryland: Baltimore, Annapolis, Chesapeake Bay area, Ocean City (overlaid on410)"
  },
  "450": {
    "Region":"QC",
    "TimezoneOffset":"1.25",
    "Description":"Canada: Southeastern Quebec; suburbs outside metro Montreal (see overlay579)"
  },
  "456": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Inbound International"
  },
  "458": {
    "Region":"OR",
    "TimezoneOffset":"1.142857143",
    "Description":"Oregon: Eugene, Medford (overlaid on541)"
  },
  "464": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Illinois: south suburbs of Chicago (see630; overlaid on708)"
  },
  "469": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Dallas Metro (overlays214/972)"
  },
  "470": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"Georgia: Greater Atlanta Metropolitan Area (overlaid on404/770/678; mand 9/2/01)"
  },
  "473": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Grenada (\"new\" -- split from809)"
  },
  "475": {
    "Region":"CT",
    "TimezoneOffset":"-5",
    "Description":"Connecticut: New Haven, Greenwich, southwestern (postponed; was perm 1/6/01; mand 3/1/01???)"
  },
  "478": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"Central Georgia: Macon (split from912; see also229; perm 8/1/00; mand 8/1/01)"
  },
  "479": {
    "Region":"AR",
    "TimezoneOffset":"-6",
    "Description":"NW Arkansas: Fort Smith, Fayetteville, Springdale, Bentonville (SPLIt from501, perm 1/19/02, mand 7/20/02)"
  },
  "480": {
    "Region":"AZ",
    "TimezoneOffset":"-7*",
    "Description":"Arizona: East Phoenix (see520; also Phoenix split602,623)"
  },
  "481": {
    "Region":"QC",
    "TimezoneOffset":"1.25",
    "Description":"Canada: NE Quebec: Quebec (see overlay418)"
  },
  "484": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"SE Pennsylvania: Allentown, Bethlehem, Reading, West Chester, Norristown (see610)"
  },
  "500": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Personal Communication Service"
  },
  "501": {
    "Region":"AR",
    "TimezoneOffset":"-6",
    "Description":"Central Arkansas: Little Rock, Hot Springs, Conway (see split479)"
  },
  "502": {
    "Region":"KY",
    "TimezoneOffset":"-5",
    "Description":"N Central Kentucky: Louisville (see270)"
  },
  "503": {
    "Region":"OR",
    "TimezoneOffset":"-8",
    "Description":"Oregon (see458,541,971)"
  },
  "504": {
    "Region":"LA",
    "TimezoneOffset":"-6",
    "Description":"E Louisiana: New Orleans metro area (see splits225,985)"
  },
  "505": {
    "Region":"NM",
    "TimezoneOffset":"-7",
    "Description":"North central and northwestern New Mexico (Albuquerque, Santa Fe, Los Alamos; see split575, eff 10/07/07)"
  },
  "506": {
    "Region":"NB",
    "TimezoneOffset":"-4",
    "Description":"Canada: New Brunswick"
  },
  "507": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"S Minnesota: Rochester, Mankato, Worthington"
  },
  "508": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Cent. Massachusetts: Framingham; Cape Cod (see split978, overlay774)"
  },
  "509": {
    "Region":"WA",
    "TimezoneOffset":"-8",
    "Description":"E and Central Washington state: Spokane, Yakima, Walla Walla, Ellensburg"
  },
  "510": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: Oakland, East Bay (see925)"
  },
  "511": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Nationwide travel information"
  },
  "512": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"S Texas: Austin (see split361; overlay737, perm 11/10/01)"
  },
  "513": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"SW Ohio: Cincinnati (see split937; overlay283cancelled)"
  },
  "514": {
    "Region":"QC",
    "TimezoneOffset":"-5",
    "Description":"Canada: SW Quebec: Montreal city (see overlay438, eff 10/10/03, mand 2/7/04)"
  },
  "515": {
    "Region":"IA",
    "TimezoneOffset":"-6",
    "Description":"Cent. Iowa: Des Moines (see split641)"
  },
  "516": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York: Nassau County, Long Island; Hempstead (see split631)"
  },
  "517": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"Cent. Michigan: Lansing (see split989)"
  },
  "518": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"NE New York: Albany"
  },
  "519": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: SW Ontario: Windsor (see overlay226,548)"
  },
  "520": {
    "Region":"AZ",
    "TimezoneOffset":"-7*",
    "Description":"SE Arizona: Tucson area (split from602; see split928)"
  },
  "530": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"NE California: Eldorado County area, excluding Eldorado Hills itself: incl cities of Auburn, Chico, Redding, So. Lake Tahoe, Marysville, Nevada City/Grass Valley (split from916)"
  },
  "539": {
    "Region":"OK",
    "TimezoneOffset":"-6",
    "Description":"E Oklahoma: Tulsa area (overlaid on918)"
  },
  "540": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"Western and Southwest Virginia: Shenandoah and Roanoke valleys: Fredericksburg, Harrisonburg, Roanoke, Salem, Lexington and nearby areas (see split276; split from703)"
  },
  "541": {
    "Region":"OR",
    "TimezoneOffset":"1.142857143",
    "Description":"Oregon: Eugene, Medford (split from503;503retains NW part [Portland/Salem], all else moves to541; eastern oregon is UTC-7). Also serves small part of northern California (NE corner of Del Norte County). (See overlay458.)"
  },
  "548": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: Southwestern Ontario (London, Sarnia, Kitchener-Waterloo and Brantford; overlaid on226,519)"
  },
  "551": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"N New Jersey: Jersey City, Hackensack (overlaid on201)"
  },
  "555": {
    "Region":"--",
    "TimezoneOffset":"?",
    "Description":"Reserved for directory assistance applications"
  },
  "557": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"SE Missouri: St Louis metro area only (cancelled: overlaid on314)"
  },
  "559": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Central California: Fresno (split from209)"
  },
  "561": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"S. Central Florida: Palm Beach County (West Palm Beach, Boca Raton, Vero Beach; see split772, eff 2/11/02; mand 11/11/02)"
  },
  "562": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: Long Beach (split from310Los Angeles)"
  },
  "563": {
    "Region":"IA",
    "TimezoneOffset":"-6",
    "Description":"E Iowa: Davenport, Dubuque (split from319, eff 3/25/01)"
  },
  "564": {
    "Region":"WA",
    "TimezoneOffset":"-8",
    "Description":"W Washington State: Olympia, Bellingham (overlaid on360; see also206,253,425; assigned but not in use)"
  },
  "567": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"NW Ohio: Toledo (overlaid on419, perm 1/1/02)"
  },
  "570": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"NE and N Central Pennsylvania: Wilkes-Barre, Scranton (see717; see overlay272)"
  },
  "571": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"Northern Virginia: Arlington, McLean, Tysons Corner (to be overlaid on7033/1/00; see earlier split540)"
  },
  "573": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"SE Missouri: excluding St Louis metro area, includes Central/East Missouri, area between St. Louis and Kansas City"
  },
  "574": {
    "Region":"IN",
    "TimezoneOffset":"-5",
    "Description":"N Indiana: Elkhart, South Bend (split from219)"
  },
  "575": {
    "Region":"NM",
    "TimezoneOffset":"-7",
    "Description":"New Mexico (Las Cruces, Alamogordo, Roswell; split from505, eff 10/07/07)"
  },
  "579": {
    "Region":"QC",
    "TimezoneOffset":"1.25",
    "Description":"Canada: Southeastern Quebec; suburbs outside metro Montreal (overlaid on450)"
  },
  "580": {
    "Region":"OK",
    "TimezoneOffset":"-6",
    "Description":"W Oklahoma (rural areas outside Oklahoma City; split from405)"
  },
  "585": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"NW New York: Rochester (split from716)"
  },
  "586": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"Michigan: Macomb County (split from810; perm 9/22/01, mand 3/23/02)"
  },
  "587": {
    "Region":"AB",
    "TimezoneOffset":"-7",
    "Description":"Alberta (see403780825)"
  },
  "600": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Canadian Services"
  },
  "601": {
    "Region":"MS",
    "TimezoneOffset":"-6",
    "Description":"Mississippi: Meridian, Jackson area (see splits228,662; overlay769)"
  },
  "602": {
    "Region":"AZ",
    "TimezoneOffset":"-7*",
    "Description":"Arizona: Phoenix (see520; also Phoenix split480,623)"
  },
  "603": {
    "Region":"NH",
    "TimezoneOffset":"-5",
    "Description":"New Hampshire"
  },
  "604": {
    "Region":"BC",
    "TimezoneOffset":"-8",
    "Description":"Canada: British Columbia: Greater Vancouver (overlay778, perm 11/3/01; see250)"
  },
  "605": {
    "Region":"SD",
    "TimezoneOffset":"0.857142857",
    "Description":"South Dakota"
  },
  "606": {
    "Region":"KY",
    "TimezoneOffset":"0.833333333",
    "Description":"E Kentucky: area east of Frankfort: Ashland (see859)"
  },
  "607": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"S Cent. New York: Ithaca, Binghamton; Catskills"
  },
  "608": {
    "Region":"WI",
    "TimezoneOffset":"-6",
    "Description":"SW Wisconsin: Madison"
  },
  "609": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"S New Jersey: Trenton (see856)"
  },
  "610": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"SE Pennsylvania: Allentown, Bethlehem, Reading, West Chester, Norristown (see overlays484,835)"
  },
  "611": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Reserved for special applications"
  },
  "612": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"Cent. Minnesota: Minneapolis (split from St. Paul, see651; see splits763,952)"
  },
  "613": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: SE Ontario: Ottawa (see overlay343)"
  },
  "614": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"SE Ohio: Columbus (see overlay380)"
  },
  "615": {
    "Region":"TN",
    "TimezoneOffset":"-6",
    "Description":"Northern Middle Tennessee: Nashville metro area (see423,931; see overlay629, eff 2014)"
  },
  "616": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"W Michigan: Holland, Grand Haven, Greenville, Grand Rapids, Ionia (see split269)"
  },
  "617": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Massachusetts: greater Boston (see overlay857)"
  },
  "618": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"S Illinois: Centralia"
  },
  "619": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: San Diego (see split760; overlay858,935)"
  },
  "620": {
    "Region":"KS",
    "TimezoneOffset":"-6",
    "Description":"S Kansas: Wichita (split from316; perm 2/3/01)"
  },
  "623": {
    "Region":"AZ",
    "TimezoneOffset":"-7*",
    "Description":"Arizona: West Phoenix (see520; also Phoenix split480,602)"
  },
  "626": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"E S California: Pasadena (split from818Los Angeles)"
  },
  "627": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"No longer in use [was Napa, Sonoma counties (perm 10/13/01, mand 4/13/02); now707]"
  },
  "628": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: San Francisco County and Marin County on the north side of the Golden Gate Bridge, extending north to Sonoma County (overlaid on415, eff 2/2015)"
  },
  "629": {
    "Region":"TN",
    "TimezoneOffset":"-6",
    "Description":"Northern Middle Tennessee: Nashville metro area (see423,931; overlaid on615, eff 2014)"
  },
  "630": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"W NE Illinois, western suburbs of Chicago (part of what used to be708; overlay331)"
  },
  "631": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York: Suffolk County, Long Island; Huntington, Riverhead (split516)"
  },
  "636": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"Missouri: W St. Louis metro area of St. Louis county, St. Charles County, Jefferson County area south (between314and573)"
  },
  "639": {
    "Region":"SK",
    "TimezoneOffset":"-6/-7*",
    "Description":"Canada: Saskatchewan (overlaid on306)"
  },
  "641": {
    "Region":"IA",
    "TimezoneOffset":"-6",
    "Description":"Iowa: Mason City, Marshalltown, Creston, Ottumwa (split from515; perm 7/9/00)"
  },
  "646": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York (overlay212/917) NYC (mostly mobile)"
  },
  "647": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: S Cent. Ontario: Toronto (overlaid on416)"
  },
  "649": {
    "Region":"None",
    "TimezoneOffset":"-5",
    "Description":"Turks & Caicos Islands"
  },
  "650": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: Peninsula south of San Francisco -- San Mateo County, parts of Santa Clara County (split from415)"
  },
  "651": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"Cent. Minnesota: St. Paul (split from Minneapolis, see612)"
  },
  "657": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Northern and western Orange County (overlaid on714)"
  },
  "660": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"N Missouri (split from816)"
  },
  "661": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: N Los Angeles, Mckittrick, Mojave, Newhall, Oildale, Palmdale, Taft, Tehachapi, Bakersfield, Earlimart, Lancaster (split from805)"
  },
  "662": {
    "Region":"MS",
    "TimezoneOffset":"-6",
    "Description":"N Mississippi: Tupelo, Grenada (split from601)"
  },
  "664": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Montserrat (split from809)"
  },
  "669": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Cent. Coastal California: San Jose (overlaid on408; eff 10/20/2012)"
  },
  "670": {
    "Region":"MP",
    "TimezoneOffset":"+10*",
    "Description":"Commonwealth of the Northern Mariana Islands (CNMI, US Commonwealth)"
  },
  "671": {
    "Region":"GU",
    "TimezoneOffset":"+10*",
    "Description":"Guam"
  },
  "678": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"N Georgia: metropolitan Atlanta (overlay; see404,770)"
  },
  "679": {
    "Region":"MI",
    "TimezoneOffset":"0.833333333",
    "Description":"Michigan: Dearborn area (overlaid on313; assigned but not in use)"
  },
  "681": {
    "Region":"WV",
    "TimezoneOffset":"-5",
    "Description":"West Virginia (overlaid on304)"
  },
  "682": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Fort Worth areas (perm 10/7/00, mand 12/9/00)"
  },
  "684": {
    "Region":"None",
    "TimezoneOffset":"-11",
    "Description":"American Samoa"
  },
  "689": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Central Florida: Metro Orlando (see overlay321; overlaid on407, assigned but not in use)"
  },
  "700": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Interexchange Carrier Services"
  },
  "701": {
    "Region":"ND",
    "TimezoneOffset":"-6",
    "Description":"North Dakota"
  },
  "702": {
    "Region":"NV",
    "TimezoneOffset":"-8",
    "Description":"S. Nevada: Clark County, incl Las Vegas (overlay725, eff 6/2014; see also775)"
  },
  "703": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"Northern Virginia: Arlington, McLean, Tysons Corner (see split540; overlay571)"
  },
  "704": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"W North Carolina: Charlotte (see split828, overlay980)"
  },
  "705": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: NE Ontario: Sault Ste. Marie/N Ontario: N Bay, Sudbury"
  },
  "706": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"N Georgia: Columbus, Augusta (see overlay762)"
  },
  "707": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"NW California: Santa Rosa, Napa, Vallejo, American Canyon, Fairfield"
  },
  "708": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Illinois: southern and western suburbs of Chicago (see630; overlay464)"
  },
  "709": {
    "Region":"NL",
    "TimezoneOffset":"1.142857143",
    "Description":"Canada: Newfoundland and Labrador"
  },
  "710": {
    "Region":"None",
    "TimezoneOffset":"?",
    "Description":"US Government"
  },
  "711": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Telecommunications Relay Services"
  },
  "712": {
    "Region":"IA",
    "TimezoneOffset":"-6",
    "Description":"W Iowa: Council Bluffs"
  },
  "713": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Mid SE Texas: central Houston (split,281; overlay832)"
  },
  "714": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"Northern and western Orange County (see split949, overlay657)"
  },
  "715": {
    "Region":"WI",
    "TimezoneOffset":"-6",
    "Description":"N Wisconsin: Eau Claire, Wausau, Superior"
  },
  "716": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"NW New York: Buffalo (see split585)"
  },
  "717": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"E Pennsylvania: Harrisburg (see split570)"
  },
  "718": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York City, New York (Queens, Staten Island, The Bronx, and Brooklyn; also Marble Hill section of Manhattan; see212,347,929)"
  },
  "719": {
    "Region":"CO",
    "TimezoneOffset":"-7",
    "Description":"SE Colorado: Pueblo, Colorado Springs"
  },
  "720": {
    "Region":"CO",
    "TimezoneOffset":"-7",
    "Description":"Central Colorado: Denver (overlaid on303)"
  },
  "721": {
    "Region":"None",
    "TimezoneOffset":"-4",
    "Description":"Sint Maarten (used to be country code +599)"
  },
  "724": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"SW Pennsylvania (areas outside metro Pittsburgh; split from412)"
  },
  "725": {
    "Region":"NV",
    "TimezoneOffset":"-8",
    "Description":"S. Nevada: Clark County, incl Las Vegas (overlaid on702, eff 6/2014; see also775)"
  },
  "727": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida Tampa Metro: Saint Petersburg, Clearwater (Pinellas and parts of Pasco County; split from813)"
  },
  "731": {
    "Region":"TN",
    "TimezoneOffset":"-6",
    "Description":"W Tennessee: outside Memphis metro area (split from901, perm 2/12/01, mand 9/17/01)"
  },
  "732": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"Cent. New Jersey: Toms River, New Brunswick, Bound Brook (see overlay848)"
  },
  "734": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"SE Michigan: west and south of Detroit -- Ann Arbor, Monroe (split from313)"
  },
  "737": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"S Texas: Austin (overlaid on512, suspended; see also361)"
  },
  "740": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"SE and Central Ohio (outside Columbus; split from614; overlay220)"
  },
  "747": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: Los Angeles, Agoura Hills, Calabasas, Hidden Hills, and Westlake Village (see818; implementation suspended)"
  },
  "754": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida: Broward County area, incl Ft. Lauderdale (overlaid on954; perm 8/1/01, mand 9/1/01)"
  },
  "757": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"E Virginia: Tidewater / Hampton Roads area -- Norfolk, Virginia Beach, Chesapeake, Portsmouth, Hampton, Newport News, Suffolk (part of what used to be804)"
  },
  "758": {
    "Region":"None",
    "TimezoneOffset":"-4",
    "Description":"St. Lucia (split from809)"
  },
  "760": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: San Diego North County to Sierra Nevada (split from619; see overlay442)"
  },
  "762": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"N Georgia: Columbus, Augusta (overlaid on706)"
  },
  "763": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"Minnesota: Minneapolis NW (split from612; see also952)"
  },
  "764": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"(overlay on650; SUSPENDED)"
  },
  "765": {
    "Region":"IN",
    "TimezoneOffset":"-5",
    "Description":"Indiana: outside Indianapolis (split from317)"
  },
  "767": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Dominica (split from809)"
  },
  "769": {
    "Region":"MS",
    "TimezoneOffset":"-6",
    "Description":"Mississippi: Meridian, Jackson area (overlaid on601; perm 7/19/04, mand 3/14/05)"
  },
  "770": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"Georgia: Atlanta suburbs: outside of I-285ring road (part of what used to be404; see also overlay678)"
  },
  "772": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"S. Central Florida: St. Lucie, Martin, and Indian River counties (split from561; eff 2/11/02; mand 11/11/02)"
  },
  "773": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Illinois: city of Chicago, outside the loop (see312; overlay872)"
  },
  "774": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Cent. Massachusetts: Framingham; Cape Cod (see split978, overlaid on508, eff 4/2/01)"
  },
  "775": {
    "Region":"NV",
    "TimezoneOffset":"-8",
    "Description":"N. Nevada: Reno (all of NV except Clark County area; see702)"
  },
  "778": {
    "Region":"BC",
    "TimezoneOffset":"-8",
    "Description":"Canada: British Columbia: Greater Vancouver (overlaid on604, per 11/3/01; see also250)"
  },
  "779": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"NW Illinois: Rockford, Kankakee (overlaid on815; eff 8/19/06, mand 2/17/07)"
  },
  "780": {
    "Region":"AB",
    "TimezoneOffset":"-7",
    "Description":"Canada: Northern Alberta, north of Lacombe (see403,825)"
  },
  "781": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Massachusetts: Boston surburbs, to the north and west (see splits617,508; overlay339)"
  },
  "782": {
    "Region":"NS",
    "TimezoneOffset":"-4",
    "Description":"Nova Scotia & Prince Edward Island (to be overlaid on902, eff 11/30/14)"
  },
  "784": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"St. Vincent & Grenadines (split from809)"
  },
  "785": {
    "Region":"KS",
    "TimezoneOffset":"-6",
    "Description":"N & W Kansas: Topeka (split from913)"
  },
  "786": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"SE Florida, Monroe County (Miami; overlaid on305)"
  },
  "787": {
    "Region":"PR",
    "TimezoneOffset":"-4*",
    "Description":"Puerto Rico (see overlay939, perm 8/1/01)"
  },
  "800": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"US/Canada toll free (see888,877,866,855,844,833,822)"
  },
  "801": {
    "Region":"UT",
    "TimezoneOffset":"-7",
    "Description":"Utah: Salt Lake City Metro (see split385, eff 3/30/02; see also split435)"
  },
  "802": {
    "Region":"VT",
    "TimezoneOffset":"-5",
    "Description":"Vermont"
  },
  "803": {
    "Region":"SC",
    "TimezoneOffset":"-5",
    "Description":"South Carolina: Columbia, Aiken, Sumter (see843,864)"
  },
  "804": {
    "Region":"VA",
    "TimezoneOffset":"-5",
    "Description":"E Virginia: Richmond (see splits757,434)"
  },
  "805": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S Cent. and Cent. Coastal California: Ventura County, Santa Barbara County: San Luis Obispo, Thousand Oaks, Carpinteria, Santa Barbara, Santa Maria, Lompoc, Santa Ynez Valley / Solvang (see661split)"
  },
  "806": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Panhandle Texas: Amarillo, Lubbock"
  },
  "807": {
    "Region":"ON",
    "TimezoneOffset":"0.833333333",
    "Description":"Canada: W Ontario: Thunder Bay region to Manitoba border"
  },
  "808": {
    "Region":"HI",
    "TimezoneOffset":"-10*",
    "Description":"Hawaii"
  },
  "809": {
    "Region":"None",
    "TimezoneOffset":"-4",
    "Description":"Dominican Republic (see splits264,268,284,340,441,473,664,758,767,784,868,876; overlay829)"
  },
  "810": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"E Michigan: Flint, Pontiac (see248; split586)"
  },
  "811": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Reserved for special applications"
  },
  "812": {
    "Region":"IN",
    "TimezoneOffset":"1.2",
    "Description":"S Indiana: Evansville, Cincinnati outskirts in IN, Columbus, Bloomington (mostly GMT-5)"
  },
  "813": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"SW Florida: Tampa Metro (splits727St. Petersburg, Clearwater, and941Sarasota)"
  },
  "814": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"Cent. Pennsylvania: Erie"
  },
  "815": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"NW Illinois: Rockford, Kankakee (see overlay779; eff 8/19/06, mand 2/17/07)"
  },
  "816": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"N Missouri: Kansas City (see split660, overlay975)"
  },
  "817": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"N Cent. Texas: Fort Worth area (see254,940)"
  },
  "818": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: Los Angeles: San Fernando Valley (see213,310,562,626,747)"
  },
  "819": {
    "Region":"QC",
    "TimezoneOffset":"-5",
    "Description":"NW Quebec: Trois Rivieres, Sherbrooke, Outaouais (Gatineau, Hull), and the Laurentians (up to St Jovite / Tremblant) (see split867; see overlay873)"
  },
  "822": {
    "Region":"None",
    "TimezoneOffset":"?",
    "Description":"US/Canada toll free (proposed, may not be in use yet)"
  },
  "825": {
    "Region":"AB",
    "TimezoneOffset":"-7",
    "Description":"Alberta (overlay; see403587780)"
  },
  "828": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"W North Carolina: Asheville (split from704)"
  },
  "829": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Dominican Republic (perm 1/31/05; mand 8/1/05; overlaid on809)"
  },
  "830": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: region surrounding San Antonio (split from210)"
  },
  "831": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: central coast area from Santa Cruz through Monterey County"
  },
  "832": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Houston (overlay713/281)"
  },
  "833": {
    "Region":"None",
    "TimezoneOffset":"?",
    "Description":"US/Canada toll free (proposed, may not be in use yet)"
  },
  "835": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"SE Pennsylvania: Allentown, Bethlehem, Reading, West Chester, Norristown (overlaid on610, eff 5/1/01; see also484)"
  },
  "843": {
    "Region":"SC",
    "TimezoneOffset":"-5",
    "Description":"South Carolina, coastal area: Charleston, Beaufort, Myrtle Beach (split from803)"
  },
  "844": {
    "Region":"None",
    "TimezoneOffset":"?",
    "Description":"US/Canada toll free (proposed, may not be in use yet)"
  },
  "845": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York: Poughkeepsie; Nyack, Nanuet, Valley Cottage, New City, Putnam, Dutchess, Rockland, Orange, Ulster and parts of Sullivan counties in New York's lower Hudson Valley and Delaware County in the Catskills (see914; perm 6/5/00)"
  },
  "847": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Northern NE Illinois: northwestern suburbs of chicago (Evanston, Waukegan, Northbrook; see overlay224)"
  },
  "848": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"Cent. New Jersey: Toms River, New Brunswick, Bound Brook (see overlay732)"
  },
  "849": {
    "Region":"--",
    "TimezoneOffset":"-4",
    "Description":"Dominican Republic: Santo Domingo"
  },
  "850": {
    "Region":"FL",
    "TimezoneOffset":"1.2",
    "Description":"Florida panhandle, from east of Tallahassee to Pensacola (split from904); western panhandle (Pensacola, Panama City) are UTC-6"
  },
  "855": {
    "Region":"--",
    "TimezoneOffset":"?",
    "Description":"US/Canada toll free"
  },
  "856": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"SW New Jersey: greater Camden area, Mt Laurel (split from609)"
  },
  "857": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Massachusetts: greater Boston (overlaid on617, eff 4/2/01)"
  },
  "858": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: San Diego (see split760; overlay619,935)"
  },
  "859": {
    "Region":"KY",
    "TimezoneOffset":"-5",
    "Description":"N and Central Kentucky: Lexington; suburban KY counties of Cincinnati OH metro area; Covington, Newport, Ft. Thomas, Ft. Wright, Florence (split from606)"
  },
  "860": {
    "Region":"CT",
    "TimezoneOffset":"-5",
    "Description":"Connecticut: areas outside of Fairfield and New Haven Counties (split from203, overlay959)"
  },
  "862": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"N New Jersey: Newark Paterson Morristown (overlaid on973)"
  },
  "863": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida: Lakeland, Polk County (split from941)"
  },
  "864": {
    "Region":"SC",
    "TimezoneOffset":"-5",
    "Description":"South Carolina, upstate area: Greenville, Spartanburg (split from803)"
  },
  "865": {
    "Region":"TN",
    "TimezoneOffset":"-5",
    "Description":"E Tennessee: Knoxville, Knox and adjacent counties (split from423; part of what used to be615)"
  },
  "866": {
    "Region":"None",
    "TimezoneOffset":"?",
    "Description":"US/Canada toll free"
  },
  "867": {
    "Region":"YT",
    "TimezoneOffset":"0.014880952",
    "Description":"Canada: Yukon, Northwest Territories, Nunavut (split from403/819)"
  },
  "868": {
    "Region":"None",
    "TimezoneOffset":"-4",
    "Description":"Trinidad and Tobago (\"new\" -- see809)"
  },
  "869": {
    "Region":"None",
    "TimezoneOffset":"-4",
    "Description":"St. Kitts & Nevis"
  },
  "870": {
    "Region":"AR",
    "TimezoneOffset":"-6",
    "Description":"Arkansas: areas outside of west/central AR: Jonesboro, etc"
  },
  "872": {
    "Region":"IL",
    "TimezoneOffset":"-6",
    "Description":"Illinois: Chicago (downtown only -- in the loop; see773; overlaid on312and773)"
  },
  "873": {
    "Region":"QC",
    "TimezoneOffset":"-5",
    "Description":"NW Quebec: Trois Rivieres, Sherbrooke, Outaouais (Gatineau, Hull), and the Laurentians (up to St Jovite / Tremblant) (overlaid on819)"
  },
  "876": {
    "Region":"None",
    "TimezoneOffset":"-5",
    "Description":"Jamaica (split from809)"
  },
  "877": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"US/Canada toll free"
  },
  "878": {
    "Region":"PA",
    "TimezoneOffset":"-5",
    "Description":"Pittsburgh, New Castle (overlaid on412, perm 8/17/01, mand t.b.a.)"
  },
  "880": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Paid Toll-Free Service"
  },
  "881": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Paid Toll-Free Service"
  },
  "882": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Paid Toll-Free Service"
  },
  "888": {
    "Region":"--",
    "TimezoneOffset":"?",
    "Description":"US/Canada toll free"
  },
  "898": {
    "Region":"--",
    "TimezoneOffset":"?",
    "Description":"VoIP service"
  },
  "900": {
    "Region":"--",
    "TimezoneOffset":"?",
    "Description":"US toll calls -- prices vary with the number called"
  },
  "901": {
    "Region":"TN",
    "TimezoneOffset":"-6",
    "Description":"W Tennessee: Memphis metro area (see615,931, split731)"
  },
  "902": {
    "Region":"NS",
    "TimezoneOffset":"-4",
    "Description":"Canada: Nova Scotia, Prince Edward Island (see overlay782)"
  },
  "903": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"NE Texas: Tyler (see overlay430, eff 7/20/02)"
  },
  "904": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"N Florida: Jacksonville (see splits352,386,850)"
  },
  "905": {
    "Region":"ON",
    "TimezoneOffset":"-5",
    "Description":"Canada: S Cent. Ontario: Greater Toronto Area -- Durham, Halton, Hamilton-Wentworth, Niagara, Peel, York, and southern Simcoe County (excluding Toronto -- see overlay289,365, splits416,647)"
  },
  "906": {
    "Region":"MI",
    "TimezoneOffset":"1.2",
    "Description":"Upper Peninsula Michigan: Sault Ste. Marie, Escanaba, Marquette (UTC-6 towards the WI border)"
  },
  "907": {
    "Region":"AK",
    "TimezoneOffset":"-9",
    "Description":"Alaska"
  },
  "908": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"Cent. New Jersey: Elizabeth, Basking Ridge, Somerville, Bridgewater, Bound Brook"
  },
  "909": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: Inland empire: San Bernardino (see split951), Riverside"
  },
  "910": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"S Cent. North Carolina: Fayetteville, Wilmington (see336)"
  },
  "911": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Emergency"
  },
  "912": {
    "Region":"GA",
    "TimezoneOffset":"-5",
    "Description":"SE Georgia: Savannah (see splits229,478)"
  },
  "913": {
    "Region":"KS",
    "TimezoneOffset":"-6",
    "Description":"Kansas: Kansas City area (see785)"
  },
  "914": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"S New York: Westchester County (see845)"
  },
  "915": {
    "Region":"TX",
    "TimezoneOffset":"1.166666667",
    "Description":"W Texas: El Paso (see splits325eff 4/5/03;432, eff 4/5/03)"
  },
  "916": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"NE California: Sacramento, Walnut Grove, Lincoln, Newcastle and El Dorado Hills (split to530)"
  },
  "917": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York: New York City (cellular, see646)"
  },
  "918": {
    "Region":"OK",
    "TimezoneOffset":"-6",
    "Description":"E Oklahoma: Tulsa (see overlay539)"
  },
  "919": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"E North Carolina: Raleigh (see split252, overlay984)"
  },
  "920": {
    "Region":"WI",
    "TimezoneOffset":"-6",
    "Description":"NE Wisconsin: Appleton, Green Bay, Sheboygan, Fond du Lac (from Beaver Dam NE to Oshkosh, Appleton, and Door County; part of what used to be414)"
  },
  "925": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: Contra Costa area: Antioch, Concord, Pleasanton, Walnut Creek (split from510)"
  },
  "927": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida: Cellular coverage in Orlando area"
  },
  "928": {
    "Region":"AZ",
    "TimezoneOffset":"-7*",
    "Description":"Central and Northern Arizona: Prescott, Flagstaff, Yuma (split from520)"
  },
  "929": {
    "Region":"NY",
    "TimezoneOffset":"-5",
    "Description":"New York City, New York (Queens, Staten Island, The Bronx, and Brooklyn; also Marble Hill section of Manhattan; see212,347,718)"
  },
  "931": {
    "Region":"TN",
    "TimezoneOffset":"-6",
    "Description":"Middle Tennessee: semi-circular ring around Nashville (split from615)"
  },
  "935": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"S California: San Diego (see split760; overlay858,619; assigned but not in use)"
  },
  "936": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"SE Texas: Conroe, Lufkin, Nacogdoches, Crockett (split from409, see also979)"
  },
  "937": {
    "Region":"OH",
    "TimezoneOffset":"-5",
    "Description":"SW Ohio: Dayton (part of what used to be513)"
  },
  "939": {
    "Region":"PR",
    "TimezoneOffset":"-4*",
    "Description":"Puerto Rico (overlaid on787, perm 8/1/01)"
  },
  "940": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"N Cent. Texas: Denton, Wichita Falls (split from254,817)"
  },
  "941": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"SW Florida: Sarasota and Manatee counties (part of what used to be813; see split863)"
  },
  "947": {
    "Region":"MI",
    "TimezoneOffset":"0.833333333",
    "Description":"Michigan: Oakland County (overlays248, perm 5/5/01)"
  },
  "949": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: S Coastal Orange County (split from714)"
  },
  "951": {
    "Region":"CA",
    "TimezoneOffset":"-8",
    "Description":"California: W Riverside County (split from909; eff 7/17/04)"
  },
  "952": {
    "Region":"MN",
    "TimezoneOffset":"-6",
    "Description":"Minnesota: Minneapolis SW, Bloomington (split from612; see also763)"
  },
  "954": {
    "Region":"FL",
    "TimezoneOffset":"-5",
    "Description":"Florida: Broward County area, incl Ft. Lauderdale (part of what used to be305, see overlay754)"
  },
  "956": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Valley of Texas area; Harlingen, Laredo (split from210)"
  },
  "957": {
    "Region":"NM",
    "TimezoneOffset":"-7",
    "Description":"New Mexico (pending; region unknown)"
  },
  "959": {
    "Region":"CT",
    "TimezoneOffset":"-5",
    "Description":"Connecticut: Hartford, New London (postponed; was overlaid on860perm 1/6/01; mand 3/1/01???)"
  },
  "970": {
    "Region":"CO",
    "TimezoneOffset":"-7",
    "Description":"N and W Colorado (part of what used to be303)"
  },
  "971": {
    "Region":"OR",
    "TimezoneOffset":"-8",
    "Description":"Oregon: Metropolitan Portland, Salem/Keizer area, incl Cricket Wireless (see503; perm 10/1/00)"
  },
  "972": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"Texas: Dallas Metro (overlays214/469)"
  },
  "973": {
    "Region":"NJ",
    "TimezoneOffset":"-5",
    "Description":"N New Jersey: Newark, Paterson, Morristown (see overlay862; split from201)"
  },
  "975": {
    "Region":"MO",
    "TimezoneOffset":"-6",
    "Description":"N Missouri: Kansas City (overlaid on816)"
  },
  "976": {
    "Region":"--",
    "TimezoneOffset":"--",
    "Description":"Unassigned"
  },
  "978": {
    "Region":"MA",
    "TimezoneOffset":"-5",
    "Description":"Massachusetts: north of Boston to NH (see split978-- this is the northern half of old508; see overlay351)"
  },
  "979": {
    "Region":"TX",
    "TimezoneOffset":"-6",
    "Description":"SE Texas: Bryan, College Station, Bay City (split from409, see also936)"
  },
  "980": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"North Carolina: (overlay on704; perm 5/1/00, mand 3/15/01)"
  },
  "984": {
    "Region":"NC",
    "TimezoneOffset":"-5",
    "Description":"E North Carolina: Raleigh (overlaid on919, perm 8/1/01, mand 2/5/02 POSTPONED)"
  },
  "985": {
    "Region":"LA",
    "TimezoneOffset":"-6",
    "Description":"E Louisiana: SE/N shore of Lake Pontchartrain: Hammond, Slidell, Covington, Amite, Kentwood, area SW of New Orleans, Houma, Thibodaux, Morgan City (split from504; perm 2/12/01; mand 10/22/01)"
  },
  "989": {
    "Region":"MI",
    "TimezoneOffset":"-5",
    "Description":"Upper central Michigan: Mt Pleasant, Saginaw (split from517; perm 4/7/01)"
  },
  "999": {
    "Region":"None",
    "TimezoneOffset":"None",
    "Description":"Often used by carriers to indicate that the area code information is unavailable for CNID, even though the rest of the number is present"
  }
};

/*
module.exports = {
    "snow golem": "A snow golem can be created by placing a pumpkin on top of  two snow blocks on the ground.",
    "pillar quartz block": "A pillar of quartz can be obtained by placing a block of quartz on top of a block of quartz in mine craft.",
    "firework rocket": "A firework rocket can be crafted by placing a firework star in the left middle square, a piece of paper in the center square, and gunpowder in the right middle square in a crafting table. Similar to a firework star, a firework rocket can have more gunpowder added in the bottom row to increase the duration of a rocket.",
    "rabbit stew": "Rabbit stew can be crafted by placing cooked rabbit in the top middle square, a carrot in the middle left square, a baked potato in the center square, any type of mushroom in the middle right square, and a bowl in the bottom middle square.",
    "cauldron": "A cauldron can be created by placing iron ingots in all squares but the top middle and very center squares in a crafting table.",
    "stone shovel": "All types of shovels can be crafted by placing the desired material in the top middle square, and then sticks in the two squares directly beneath that in a crafting table.",
    "red carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "book and quill": "A book and quill can be crafted by placing a book in the middle left square, an ink sac in the very center square, and a feather in the bottom middle square in a crafting table.",
    "item frame": "An item frame can be crafted by placing leather in the very center square, and eight sticks surrounding it.",
    "map": "A map can be crafted by placing a compass in the middle square and eight pieces of paper surrounding it.",
    "sticky piston": "A sticky piston can be crafted by placing a slime ball on top of a piston in a crafting window",
    "bread": "Bread can be crafted by placing three wheat across a row in a crafting table.",
    "wooden pick ax": "All types of pick axs can be crafted by placing three of the desired material across the top row, and then placing sticks in the center and bottom middle squares in a crafting table.",
    "shears": "Shears can be crafted by placing two Iron Ingots diagonal from each other.",
    "raw beef": "Raw Beef will drop from the death of a Cow or Moo shrooms.",
    "smooth red sandstone": "Smooth red sandstone can be crafted by placing four red sandstone in a two by two grid in a crafting window.",
    "prismarine crystals": "Prismarine Crystals can be obtained by defeating Guardians and Elder Guardians.",
    "oak wood slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "wooden sword": "All types of swords can be crafted by placing the desired material in the top middle and very center square, with a stick beneath them, in a crafting table",
    "stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "jungle fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "activator rail": "An activator rail can be crafted by placing a red stone torch in the very center square, sticks above and beneath it, and then six iron ingots in the remaining squares in a crafting table.",
    "farmland": "Farmland can be created by plowing the land with a hoe.",
    "gold ore": "Gold ore can be obtained by breaking gold ore blocks with an iron pick ax or better",
    "andesite": "Andesite can be mined with a pick ax or crafted by placing diorite next to cobblestone in a crafting table.",
    "rose red": "Rose red can be crafted by placing a poppy into a crafting table.",
    "iron axe": "All types of axes can be crafted by placing three of the desired material in the top left, top middle, and middle left squares, with sticks in the center and bottom middle squares in a crafting table.",
    "light blue dye": "Light blue dye can be crafted by placing lapis lazuli next to bone meal in a crafting window.",
    "gray dye": "Gray dye can be crafted by placing bonemeal next to an ink sac in a crafting window",
    "blue stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "iron horse armor": "Horse Armor can be randomly found in Dungeons, Nether fortresses, Village blacksmiths, jungle temples, desert temples, and stronghold chests.",
    "red stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "brick stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "golden leggings": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "dark oak fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "wither mob head": "Mob heads can be obtained by having a charged creeper blow up the mob whose head you want to obtain.",
    "spider eye": "A spider eye is randomly dropped by killing spiders or witches.",
    "magenta stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "brown stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "pumpkin pie": "A pumpkin pie can be crafted by placing a pumpkin in the left middle square, sugar in the very center square, and an egg in the bottom middle square in a crafting table.",
    "snowball": "A snowball can be obtained by breaking snow with a shovel.",
    "juke box": "A juke box is crafted by placing a diamond in the very center square and wood planks all around that in a crafting table",
    "sand": "Sand can be obtained by breaking sand blocks.",
    "dead bush": "Dead bushes, also known as shrubs, can be obtained with shears.",
    "brick slab": "A brick slab can be crafted by placing three brick blocks in a row in a crafting table.",
    "lily pad": "Lily pads can be found naturally on water in swamplands or underground lakes.",
    "leather pants": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "mossy cobblestone wall": "A mossy cobblestone wall is crafted by placing six mossy cobblestone across the bottom two rows in a crafting table.",
    "eleven disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chests.",
    "purple stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "magenta stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "mall disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chests.",
    "jungle wood": "All types of wood can be obtained by breaking the tree they naturally grow into.",
    "diamond ax": "All types of axes can be crafted by placing three of the desired material in the top left, top middle, and middle left squares, with sticks in the center and bottom middle squares in a crafting table.",
    "empty map": "A map can be crafted by placing a compass in the middle square and eight pieces of paper surrounding it.",
    "stone pressure plate": "A stone pressure plate can be crafted by placing two smooth stone, next to each other, horizontally, in a crafting window.",
    "trapdoor": "Trapdoors can be crafted with either wooden planks or iron ingots. To craft a wooden trapdoor, place wooden planks in all spaces in the bottom two rows. To craft an iron trapdoor, place iron ingots in a two by two grid in a crafting table.",
    "gold boots": "All boots are crafted by placing the desired material in the middle left, bottom left, middle right, and bottom right squares of a crafting table.",
    "stall disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "red stone wire": "Redstone wire is simply red stone placed on the floor.",
    "piston": "A piston can be crafted by placing an iron ingot in the center square, red stone in the bottom middle square, wooden planks across the top row, and cobblestone in the remaining squares.",
    "white stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "mine cart with furnace": "A mine cart with a furnace is crafted by placing a furnace on top of a mine cart in a crafting window.",
    "sugar": "Sugar can be obtained by placing sugar cane in a crafting window.",
    "chain mail chest plate": "Chain mail armor can only be obtained by trading with a villager or getting a rare drop off of a mob.",
    "feather": "Feathers can be randomly obtained by killing chickens.",
    "light blue stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "oak fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "stone pick ax": "All types of pick axes can be crafted by placing three of the desired material across the top row, and then placing sticks in the center and bottom middle squares in a crafting table.",
    "pink carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "monster spawner": "Monster spawners can not be obtained without cheats in mine craft.",
    "golden carrot": "A golden carrot can be crafted by placing a carrot in the very middle square and eight gold nuggets surrounding that.",
    "stick": "A stick can be crafted by placing a wooden plank on top of a wooden plank in a crafting window.",
    "diamond block": "A diamond block can be crafted by placing diamonds in every square in a crafting table.",
    "green stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "cooked chicken": "Raw Chicken can be cooked by smelting it in a furnace. Alternately, Cooked Chicken has a chance of dropping when a Chicken dies while on fire.",
    "thirteen disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "wooden trapdoor": "A wooden trapdoor can be crafted by placing wooden planks in all spaces in the bottom two rows in a crafting table.",
    "oak fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "crafting bench": "A crafting bench is crafted by placing wooden planks in a two by two grid in a crafting window.",
    "nether quartz ore": "Nether quartz ore can be randomly found in the nether. To obtain the ore instead of nether quartz, you will need to use a silk touch pick ax.",
    "golden sword": "All types of swords can be crafted by placing the desired material in the top middle and very center square, with a stick beneath them, in a crafting table",
    "gray stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "light blue stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "diamond boots": "All boots are crafted by placing the desired material in the middle left, bottom left, middle right, and bottom right squares of a crafting table.",
    "stone hoe": "All types of hoes can be crafted by placing two of the desired material in the top left, and top middle squares, with sticks in the center and bottom middle squares in a crafting table.",
    "coal ore": "Coal ore can be obtained by breaking a coal ore block with a pick ax that is enchanted with silk touch",
    "dark oak leaves": "All leaves can be obtained by using a shear on the desired leaf.",
    "t.n.t.": "T.N.T can be crafted by placing gunpowder in an x shape in a crafting grid and then placing sand in all remaining squares.",
    "brick": "A brick can be crafted by smelting clay in a furnace.",
    "potato": "Potatoes can be rarely obtained by killing zombies or, they can be found as crops in villages.",
    "orange carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "ink sack": "An ink sack can be obtained by killing a squid.",
    "red stone": "Redstone can be obtained by breaking red stone ore with an iron pick ax or better.",
    "dark oak wood": "All types of wood can be obtained by breaking the tree they naturally grow into.",
    "diorite": "Diorite can be mined with a pick ax or crafted by combining cobblestone and nether quartz in a two by two grid in a crafting table.",
    "workbench": "A workbench is crafted by placing wooden planks in a two by two grid in a crafting window.",
    "gray stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "jungle fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "magenta wool": "Magenta wool can be crafted by placing magenta dye next to any color wool in a crafting window.",
    "dirt": "Dirt can be obtained by breaking grass or dirt with a shovel.",
    "armor stand": "An Armor Stand can be crafted with six sticks and one stone slab. Take three sticks and place it across the first row. Take the remaining three sticks and place one each in the bottom left, bottom right, and center middle. Place the stone slab in the bottom middle.",
    "cooked fish": "Cooked fish is obtained by cooking fish in a furnace.",
    "lever": "A lever can be crafted by placing a stick on top of cobblestone in a crafting window.",
    "leash": "A leash can be crafted by placing a slime ball in the very center, and then placing string in the top left, top middle, left middle, and bottom right squares in a crafting table.",
    "cooked rabbit": "Cooked rabbit can be obtained by cooking raw rabbit in a furnace. Alternately, Cooked Rabbit has a chance of dropping when a Rabbit dies while on fire.",
    "jungle wood stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "mine cart with hopper": "A Mine cart With a Hopper can be crafted by placing a Hopper on top of a Mine cart in a crafting table.",
    "fermented spider eye": "Fermented spider eye can be obtained by placing a brown mushroom in the middle left square, sugar in the very center square, and a spider eye in the bottom middle square in a crafting table.",
    "raw fish": "Raw fish is randomly obtained by fishing.",
    "brown stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "sign": "A sign is crafted by placing wooden planks in the top two rows and a stick in the bottom middle square.",
    "t.n.t": "T.N.T can be crafted by placing gunpowder in an x shape in a crafting grid and then placing sand in all remaining squares.",
    "hopper": "A hopper can be crafted by placing a chest in the very center square, and then iron ingots in every square but the top middle, bottom left, and bottom right squares in a crafting grid.",
    "blaze rod": "Blaze rods can be randomly obtained by killing blazes.",
    "red stone comparator": "A red stone comparator can be crafted by placing three smooth stone across the bottom row, a nether quartz in the center square, and three red stone torches surrounding the nether quartz in a crafting table.",
    "bone": "Bones can be obtained by killing skeletons.",
    "golden horse armor": "Horse Armor can be randomly found in Dungeons, Nether fortresses, Village blacksmiths, jungle temples, desert temples, and stronghold chests.",
    "golden pants": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "rail": "A rail can be crafted by placing a stick in the very middle square and iron ingots vertically in both the first and last column in a crafting table.",
    "wheat seeds": "Wheat seeds are obtained by harvesting wheat.",
    "birch fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "purple stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "golden chestplate": "All chestplates are crafted by placing the desired material in all squares but the top middle square in a crafting table.",
    "leather boots": "All boots are crafted by placing the desired material in the middle left, bottom left, middle right, and bottom right squares of a crafting table.",
    "diamond shovel": "All types of shovels can be crafted by placing the desired material in the top middle square, and then sticks in the two squares directly beneath that in a crafting table.",
    "leather leggings": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "red sand": "Red sand can be found in Mesa biomes.",
    "vines": "Vines can only be harvested with shears. Vines spawn naturally in jungle trees or in swamplands.",
    "glass bottle": "A glass bottle is crafted by creating a V shape with three glass blocks in a crafting table.",
    "red stone ore": "Redstone ore can be found in the bottom sixteen layers on the map. If broken with an iron pick ax or better, it will drop some amount of red stone. To obtain the ore itself, one would need to use a pick ax with a silk touch enchant.",
    "emerald block": "Emerald blocks can be crafted by placing nine emeralds in a three by three grid in a crafting table.",
    "granite": "Granite can be mined with a pick ax or crafted by placing Diorite and a nether quartz next to each other in a crafting table.",
    "brown wool": "Brown wool can be crafted by placing brown dye next to any color wool in a crafting window.",
    "golden apple": "A golden apple can be crafted by placing an apple in the very center square and eight gold ingots surrounding it.",
    "birch leaves": "All leaves can be obtained by using a shear on the desired leaf.",
    "white wool": "White wool can be crated by placing four string in a two by two grid in a crafting window. It can also be obtained by placing bone meal next to any color wool in a crafting window",
    "purple carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "hardened clay": "Hardened clay can be crafted by smelting a clay block in a furnace.",
    "zombie mob head": "Mob heads can be obtained by having a charged creeper blow up the mob whose head you want to obtain.",
    "iron trapdoor": "An iron trapdoor can be crafted by placing iron ingots in a two by two grid in a crafting window.",
    "flower pot": "A flower pot is crafted by placing three bricks in a V shape in a crafting table.",
    "iron ore": "Iron ore can be obtained by breaking iron ore blocks with a stone pick ax or better",
    "jungle wood slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "birch wood slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "jungle door": "A Jungle Door can be crafted by placing six Jungle Planks down the first two columns.",
    "golden ax": "All types of axes can be crafted by placing three of the desired materials in the top left, top middle, and middle left squares, with sticks in the center and bottom middle squares in a crafting table.",
    "packed ice": "Packed ice can be found in the rare ice plains spikes biome and can only be obtained with a silk touch tool.",
    "bricks": "Bricks can be crafted by smelting clay in a furnace.",
    "light blue carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "dead shrub": "Dead bushes, also known as shrubs, can be obtained with shears.",
    "dropper": "A dropper can be crafted by placing red stone in the middle bottom square, and cobblestone in every other square but the center one.",
    "chest": "A chest is crafted by placing wooden planks, in every square but the middle square, in a crafting table.",
    "raw chicken": "Raw Chicken will drop from the death of a Chicken.",
    "raw salmon": "Raw salmon is randomly obtained by fishing.",
    "tripwire hook": "A tripwire hook can be crafted by placing an iron ingot on top of a stick on top of a wood plank in a crafting table.",
    "oak wood stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "mine cart with command block": "A mine cart with a command block can not be obtained without cheats.",
    "eye of ender": "An eye of ender can be crafted by placing blaze power next to an ender pearl in a crafting window.",
    "block of coal": "A block of coal can be crafted by placing coal in a three by three grid in a crafting window.",
    "nether star": "A Nether Star can be obtained by defeating the Wither.",
    "gravel": "Gravel can be obtained by breaking gravel blocks",
    "blue wool": "Blue wool can be crafted by placing lapis lazuli next to any color wool in a crafting window.",
    "nether quartz": "Nether Quartz can be obtained by smelting Nether Quartz Ore in a furnace.",
    "rotten flesh": "Rotten flesh can be randomly obtained by killing zombies.",
    "magenta carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "white stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "birch fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "carrots": "Carrots can be rarely obtained by killing zombies or, they can be naturally found as crops in villages.",
    "purple dye": "Purple dye can be crafted by placing lapis lazuli next to rose red in a crafting window.",
    "lapis lazuli block": "A lapis lazuli block can be obtained by entirely filling a crafting table with lapis lazuli.",
    "obsidian": "Obsidian can be mined with a diamond pick or created by placing water on top of lava. ",
    "mellohi disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music discs are found in eight percent of dungeon chests.",
    "gray wool": "Gray wool can be crafted by placing gray dye next to any color wool in a crafting window.",
    "trapped chest": "A trapped chest can be crafted by placing a tripwire hook next to a chest in a crafting window.",
    "light gray stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "iron pick ax": "All types of pick axes can be crafted by placing three of the desired material across the top row, and then placing sticks in the center and bottom middle squares in a crafting table.",
    "red mushroom": "Red mushrooms can be found naturally in darkly lit areas, mushroom biomes, or the nether.",
    "puffer fish": "A puffer fish can be randomly obtained by fishing.",
    "emerald": "Emeralds can be obtained by harvesting emerald ore.",
    "wooden shovel": "All types of shovels can be crafted by placing the desired material in the top middle square, and then sticks in the two squares directly beneath that in a crafting table.",
    "golden helmet": "All helmets are crafted by placing the desired material in all squares but the very center square and the bottom row in a crafting table/",
    "melon": "A melon can be found naturally in jungles or can be grown from melon seeds found in chest mine carts in abandoned mine shafts.",
    "clay block": "Clay is commonly found at the bottoms of rivers and lakes in shallow, circular patches. Clay blocks can also be found commonly in swamps.",
    "anvil": "An anvil can be crafted by placing three blocks of iron across the top row, an iron ingot in the very center square, and then three iron ingots across the bottom row in a crafting table.",
    "daylight sensor": "A daylight sensor can be crafted by placing three glass across the top row, three nether quartz across the middle grow, anad three wooden slabs across the bottom row in a crafting table.",
    "lead": "A lead can be crafted by placing a slime ball in the very center, and then placing string in the top left, top middle, left middle, and bottom right squares in a crafting table.",
    "sandstone": "Sandstone can be obtained in deserts or crafted by combining sand together in a two by two square.",
    "leather tunic": "All chest pieces are crafted by placing the desired material in all squares but the top middle square in a crafting table.",
    "black stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "lime stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "mine cart with t.n.t": "A Mine cart with T.N.T can be crafted by placing a T.N.T on top of a Mine cart in a crafting table.",
    "clock": "A clock is crafted by placing red stone in the very center square and surrounding it with four gold ingots in a crafting table.",
    "black carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "cocoa": "Cocoa beans come from cocoa pods, which are naturally found in jungle biomes. Cocoa beans are used as brown dye in minecraft.",
    "gold ingot": "Gold ingots can be obtained by smelting gold ore in a furnace.",
    "stone brick slab": "A stone brick slab can be crafted by placing three stone bricks in a row in a crafting table.",
    "clown fish": "A clown fish can be randomly obtained by fishing.",
    "pumpkin seeds": "Pumpkin seeds can be crafted by placing a pumpkin in a crafting window.",
    "mossy stone brick": "Mossy stone brick can be crafted by placing vines next to stone bricks in a crafting window. Mossy stone brick can also be found naturally in strongholds.",
    "cobweb": "Cobwebs can be obtained by using shears or a sword that is enchanted with silk touch",
    "milk bucket": "A milk bucket can be obtained by right clicking on a cow with an iron bucket.",
    "iron helmet": "All helmets are crafted by placing the desired material, in all squares but the very center square, and the bottom row, in a crafting table.",
    "yellow stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "light gray stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "diamond": "Diamond can be obtained by breaking diamond ore with an iron pick ax or better.",
    "stone sword": "All types of swords can be crafted by placing the desired material in the top middle and very center square, with a stick beneath them, in a crafting table",
    "cobblestone stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "bed": "A bed can be crafted by placing three wool across the top row and three wooden planks across the middle row in a crafting table.",
    "birch wood": "All types of wood can be obtained by breaking the tree they naturally grow into.",
    "quartz slab": "A quartz slab can be crafted by placing three quartz blocks in a row in a crafting table.",
    "sponge": "Sponges can be obtained by killing an elder guardian or randomly finding them in ocean monuments",
    "skeleton mob head": "Mob heads can be obtained by having a charged creeper blow up the mob whose head you want to obtain.",
    "bucket": "A bucket can be crafted by placing three iron ingots in a V shape in a crafting table.",
    "diamond sword": "All types of swords can be crafted by placing the desired material in the top middle and very center square, with a stick beneath them, in a crafting table",
    "golden shovel": "All types of shovels can be crafted by placing the desired material in the top middle square, and then sticks in the two squares directly beneath that in a crafting table.",
    "spruce wood stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "iron bars": "Iron bars can be crafted by placing six iron ingots across the bottom two rows in a crafting table. Iron bars can also be found naturally in strongholds.",
    "raw rabbit": "Raw rabbit can be randomly obtained by killing a rabbit.",
    "yellow carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "carrot on a stick": "A carrot on a stick can be crafted by placing a fishing pole in the middle left square and a carrot in the bottom middle square in a crafting window.",
    "raw pork chop": "A raw pork chop can be obtained by killing a pig.",
    "furnace": "A furnace can be crafted by placing cobblestone in every square but the middle square in a crafting table.",
    "nether brick fence": "A nether brick fence can be crafted by placing six nether brick across the bottom two rows in a crafting table.",
    "fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "diamond horse armor": "Horse Armor can be randomly found in Dungeons, Nether fortresses, Village blacksmiths, jungle temples, desert temples, and stronghold chests.",
    "red sandstone slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "birch wood plank": "Birch wood planks can be obtained by placing birch wood in a crafting table.",
    "bedrock": "Bedrock can not be obtained by a player without cheats. It is the bottom most block in the game.",
    "saddle": "Saddles can not be crafted and can only be obtained by finding them in chests inside dungeons, abandoned mine shafts, nether fortresses, desert temples, or jungle temples.",
    "light gray dye": "Light gray dye can be crafted by placing two bone meal in a vertical row next to an ink sac in a crafting window.",
    "jungle leaves": "All leaves can be obtained by using a shear on the desired leaf.",
    "blocks disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "pumpkin": "Pumpkins can be rarely be found on grass in most biomes.",
    "baked potato": "A baked potato can be obtained by smelting a potato in a furnace.",
    "leather": "Leather can be randomly obtained by killing cows or horses.",
    "light gray carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "iron boots": "All boots are crafted by placing the desired material in the middle left, bottom left, middle right, and bottom right squares of a crafting table.",
    "end stone": "End stone can be found naturally in the end dimension.",
    "chainmail leggings": "Chainmail armor can only be obtained by trading with a villager or getting a rare drop off of a mob.",
    "rabbit's foot": "A rabbit's foot can be obtained rarely by killing a rabbit.",
    "glass": "Glass can be obtained by smelting sand in a furnace.",
    "stone": "Stone can be made by smelting cobblestone in a furnace.",
    "prismarine": "Prismarine can be crafted by placing prismarine shards in a two by two grid in a crafting window.",
    "compass": "A compass is crafted by placing red stone in the very center square, and surrounding it with four iron ingots, in a crafting table.",
    "green stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "gold leggings": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "command block": "Command blocks can not be obtained without cheats in minecraft.",
    "dispenser": "A dispenser can be created by placing a bow in the very center square, red stone right beneath that, and cobblestone in every other square.",
    "poisonous potato": "A poisonous potato will randomly be dropped when harvesting potatoes.",
    "apple": "Apples randomly drop from oak and dark oak leaves. They can also be randomly found in chests in strongholds or villages.",
    "red flower": "Poppies can be found naturally on grass or created randomly by using bone meal on grass.",
    "magenta dye": "Magenta dye can be crafted by placing purple dye next to pink dye in a crafting window.",
    "brown carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "prismarine shard": "Prismarine Shards can be obtained by defeating Guardians and Elder Guardians.",
    "red stone block": "A red stone block can be crafted by placing nine red stone in a three by three grid in a crafting table.",
    "yellow stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "dandelion yellow": "Dandelion yellow is the equivalent of yellow dye in minecraft. It can be crafted by placing a dandelion or a sunflower in a crafting window.",
    "acacia wood stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares.",
    "sandstone slab": "A sandstone slab can be crated by placing three sandstone blocks in a row in a crafting table.",
    "gray carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "polished granite": "Polished Granite can be crafted by placing four granite in a two by two grid in a crafting table.",
    "mine cart": "A mine cart is crafted by placing five iron ingots in a U shape in a crafting table.",
    "brown stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "cyan stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "book": "A book is crafted by creating a two by two grid where the bottom right square is leather and all other squares are paper in a crafting window.",
    "mine cart with a chest": "A mine cart with a chest is crafted by placing a chest on top of a mine cart in a crafting window.",
    "acacia sapling": "Acacia saplings can be randomly obtained by breaking acacia leaves.",
    "paper": "Paper is crafted by placing three sugar cane, across a row, in a crafting table.",
    "gold chest plate": "All chest plates are crafted by placing the desired material in all squares but the top middle square in a crafting table.",
    "cyan stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "mushroom stew": "Mushroom stew is crafted by placing a red mushroom in the middle left square, a brown mushroom in the very center square, and a bowl in the bottom middle square in a crafting table.",
    "nether brick": "Nether Brick can be mined with a pick ax, or crafted by placing four Nether Bricks in a two by two square in a crafting table.",
    "magma cream": "Magma cream can be crafted by placing blaze powder next to a slime ball in a crafting window.",
    "snow": "Snow can be crafted by placing snowballs in a two by two grid in a crafting window.",
    "orange dye": "Orange dye can be crafted by placing rose red next to dandelion yellow in a crafting window.",
    "potion": "A potion is created by utilizing a brewing stand, cauldron, and water bottles.",
    "lime stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "white stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "boat": "A boat can be obtained by making a U shape with five wooden planks.",
    "dark prismarine": "Dark prismarine can be crafted by placing an ink sac in the very center square, and then eight placing prismarine shards around it.",
    "oak door": "A Oak Door can be crafted by placing six Oak Planks down the first two columns.",
    "cocoa beans": "Cocoa beans come from cocoa pods, which are naturally found in jungle biomes. Cocoa beans are used as brown dye in minecraft.",
    "oak wood": "All types of wood can be obtained by breaking the tree they naturally grow into.",
    "red wool": "Red wool can be crafted by placing rose red next to any color wool in a crafting window.",
    "cooked mutton": "Cooked mutton can be obtained by cooking raw mutton in a furnace. Alternately, one to two pieces of Cooked Mutton are dropped when a sheep dies while on fire.",
    "dark oak fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "iron door": "An Iron Door can be crafted by placing six Iron Ingots down the first two columns.",
    "painting": "A painting is crafted by placing wool in the very center square and surrounding it with eight sticks.",
    "spruce leaves": "All leaves can be obtained by using a shear on the desired leaf.",
    "pink stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "acacia wood slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "dark oak wood slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "chiseled sandstone": "Chiseled sandstone can be created by placing a sandstone slab on top of a sandstone slab, in a crafting window.",
    "oak wood plank": "Oak wood planks can be obtained by placing oak wood in a crafting table.",
    "cooked salmon": "Cooked salmon is obtained by cooking salmon in a furnace.",
    "iron shovel": "All types of shovels can be crafted by placing the desired material in the top middle square, and then sticks in the two squares directly beneath that in a crafting table.",
    "enchanting table": "An enchanting table can be crafted by placing a book in the top middle square, diamonds in the middle left and middle right squares, and obsidian in the very center and across the bottom row, in a crafting table.",
    "red stone repeater": "A red stone repeater can be crafted by placing smooth stone in all three squares across the bottom row, red stone in the very middle square, and red stone torches on both sides of the red stone.",
    "far disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "green carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "iron ingot": "Iron ingots can be obtained by smelting iron ore in a furnace.",
    "orange wool": "Orange wool can be crafted by placing orange dye next to any color wool in a crafting window.",
    "jungle sapling": "Jungle saplings can be randomly obtained by breaking jungle leaves.",
    "stone slab": "A stone slab can be crafted by placing three stone blocks in a row in a crafting table.",
    "light blue stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "cyan dye": "Cyan dye can be crafted by placing lapis lazuli next to cactus green in a crafting window.",
    "steak": "Raw Beef can be cooked into Steak by smelting it in a furnace. Alternately, Steak has a chance of dropping when a Cow or Moo shroom dies while on fire.",
    "orange stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "blue stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "spruce fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "coal": "Coal can be obtained by breaking a coal ore block with a wooden pick ax or better.",
    "potatoes": "Potatoes can be rarely obtained by killing zombies or, they can be found as crops in villages.",
    "light gray stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "egg": "Eggs are randomly produced by chickens. Throwing an egg has a chance to create a new chicken.",
    "spruce wood plank": "Spruce wood planks can be obtained by placing spruce wood in a crafting table.",
    "orange stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "acacia wood": "All types of wood can be obtained by breaking the tree they naturally grow into.",
    "light gray wool": "Light gray wool can be crafted by placing light gray dye next to any color wool in a crafting window.",
    "hay bale": "A hay bale can be crafted by placing wheat in a three by three grid in a crafting table.",
    "clay": "Clay is obtained by breaking clay blocks with a non silk touch tool.",
    "bowl": "A bowl can be crafted by placing three wooden planks in a v shape in a crafting table.",
    "leather helmet": "All helmets are crafted by placing the desired material in all squares but the very center square and the bottom row in a crafting table/",
    "pink stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "diamond chest plate": "All chest plates are crafted by placing the desired material in all squares but the top middle square in a crafting table.",
    "gray stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "yellow stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "snowman": "A snow golem can be created by placing a pumpkin on top of  two snow blocks on the ground.",
    "diamond ore": "Diamond ore can be found in the bottom sixteen layers on the map. One can break diamond ore with an iron pick ax or better. This will cause the diamond ore to break into a diamond. To obtain the ore, you will need to use a pick ax with the silk touch enchant.",
    "banner": "A Banner can be crafted by placing six wool across the top two rows, then placing a stick on the bottom middle. The banner will take on the color of the wool you choose.",
    "stone ax": "All types of axes can be crafted by placing three of the desired material in the top left, top middle, and middle left squares, with sticks in the center and bottom middle squares in a crafting table.",
    "firework star": "A firework star can be crafted by placing gunpower in the middle left square and any color dye in the center square in a crafting table. A firework star can also be crafted with optional ingredients such as diamonds, glow stone dust, or feathers, that are placed directly beneath the dye in a crafting table.",
    "nether wart": "Nether warts can be naturally found in nether fortresses as a plant.",
    "red stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "quartz block": "A quartz block can be crafted by placing four nether quartz in a two by two grid in a crafting table.",
    "poppy": "Poppies can be found naturally on grass or created randomly by using bone meal on grass.",
    "acacia fence": "Any type of fence can be crafted by putting a wooden plank, a stick, and then another wooden plank in the bottom two rows of a crafting table.",
    "cactus": "Cactus can be found naturally in desert biomes. ",
    "spruce door": "A Spruce Door can be crafted by placing six Spruce Planks down the first two columns.",
    "cat disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "flint and steel": "Flint and steel can be crafted by placing an iron ingot to the left of flint in a crafting window.",
    "gold pants": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "slime ball": "Slime balls are randomly dropped by killing slimes.",
    "cooked porkchop": "A cooked porkchop can be obtained by cooking a raw porkchop in a furnace or by lighting a pig on fire.",
    "polished andesite": "Polished Andesite can be crafted by placing four andesite in a two by two grid in a crafting table.",
    "prismarine bricks": "Prismarine bricks can be crafted by placing prismarine shards in a three by three grid in a crafting table.",
    "wither": "A wither can be created by placing three wither skulls on top of soul sand that is placed on the ground in a T shape.",
    "lime dye": "Lime dye can be crafted by placing cactus green next to bone meal in a crafting window.",
    "blue carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "door": "A door can be crafted by placing six Planks, down the first two columns, in a crafting table.",
    "tripwire": "Tripwire is simply string next to a tripwire hook.",
    "enchantment table": "An enchantment table can be crafted by placing a book in the top middle square, diamonds in the middle left and middle right squares, and obsidian in the very center and across the bottom row, in a crafting table.",
    "cyan carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "polished diorite": "Polished Diorite can be crafted by placing four diorite in a two by two grid in a crafting table.",
    "golden boots": "All boots are crafted by placing the desired material in the middle left, bottom left, middle right, and bottom right squares of a crafting table.",
    "iron block": "An iron block can be crafted by placing iron ingots in a three by three grid in a crafting table.",
    "acacia leaves": "All leaves can be obtained by using a shear on the desired leaf.",
    "dark oak sapling": "Dark oak saplings can be randomly obtained by breaking dark oak leaves",
    "diamond hoe": "All types of hoes can be crafted by placing two of the desired material in the top left, and top middle squares, with sticks in the center and bottom middle squares in a crafting table.",
    "dandelion": "Dandelions can be found naturally on grass or created randomly by using bone meal on grass.",
    "lapis lazuli": "Can be obtained by breaking lapis lazuli ore with a stone pick ax or better",
    "sugar cane": "Sugar cane can be found naturally near water,",
    "birch door": "A Birch Door can be crafted by placing six Birch Planks down the first two columns.",
    "cactus green": "Cactus green can be crafted by smelting a cactus in a furnace.",
    "gold block": "A gold block can be crafted by placing gold ingots in a three by three grid in a crafting table.",
    "smooth sandstone": "Smooth sandstone can be created by placing sandstone in a two by two grid in a crafting window",
    "magenta stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "note block": "A note block is crafted by placing red stone in the very center square and wooden planks all around that in a crafting table",
    "snow block": "Snow can be crafted by placing snowballs in a two by two grid in a crafting window.",
    "mob head": "Mob heads can be obtained by having a charged creeper blow up the mob whose head you want to obtain.",
    "diamond leggings": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "red sandstone": "Red sandstone can be crafted by placing four red sand in a two by two grid in a crafting window.",
    "orange stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "slime block": "A slime block can be crafted by placing slime balls in a three by three grid in a crafting window.",
    "bookshelf": "A bookshelf is crafted by placing books across the middle row and wooden planks across the top and bottom rows",
    "cake": "Cake can be crafted by placing three buckets of milk across the top row, sugar in the left middle, and right middle squares, an egg in the very center square, and three wheat across the bottom squares in a crafting table.",
    "wooden button": "A wooden button can be crafted by placing a single wooden plank in a crafting window.",
    "chiseled quartz block": "A chiseled quartz block can be obtained by placing a quartz slab on top of a quartz slab in a crafting table.",
    "stone button": "A stone button can be crafted by placing a single piece of smooth stone in a crafting window.",
    "glow stone dust": "Glow stone dust is obtained by breaking glow stone blocks.",
    "lime stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "cobblestone wall": "A cobblestone wall is crafted by placing six cobblestone across the bottom two rows in a crafting table.",
    "name tag": "Name Tags can only be obtained in three ways. The first way is by finding it in a Dungeon chest. The second way is by fishing. The last way Name Tags can be obtained is by trading with the Librarian Villagers for twenty to twenty two Emeralds.",
    "gunpowder": "Gunpowder can be randomly obtained by killing creepers.",
    "blaze powder": "Blaze powder can be obtained by placing a blaze row in a crafting window.",
    "brewing stand": "A brewing stand can be crafted by placing a blaze rod in the center square, and three cobblestone across the bottom row in a crafting table.",
    "torch": "A torch can be crafted by placing a piece of coal on top of a stick.",
    "yellow wool": "Yellow wool can be crafted by placing dandelion yellow next to any color wool in a crafting window.",
    "watermelon": "A melon can be found naturally in jungles or can be grown from melon seeds found in chest minecarts in abandoned mine shafts.",
    "wait disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "glistering melon": "A glistering melon can be crafted by placing a melon in the very center square and surrounding it with eight gold nuggets in a crafting table.",
    "netherrack": "Netherrack can be found commonly throughout the Nether dimension.",
    "leather chest plate": "All chest places are crafted by placing the desired material in all squares but the top middle square in a crafting table.",
    "wooden slab": "A wooden slab can be crafted by placing three wooden planks in a row in a crafting table.",
    "nether brick stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "ice": "Ice can be found naturally in snow biomes. If broken, or placed near a heat source, ice will turn into water. To obtain an ice block, one would need to mine it with a silk touch pick ax.",
    "large fern": "Large ferns are naturally found in jungle, taiga, and mega taiga biomes.",
    "nether brick slab": "A nether brick slab can be crafted by placing three nether brick in a row in a crafting table.",
    "spruce wood slab": "All types of slabs can be crafted by placing three of the desired materials across a row in a crafting table.",
    "iron hoe": "All types of hoes can be crafted by placing two of the desired material in the top left, and top middle squares, with sticks in the center and bottom middle squares in a crafting table.",
    "fern": "Ferns are naturally found in jungle, taiga, and mega taiga biomes.",
    "sea lantern": "A sea lantern can be crafted by placing prismarine shards in the four corners of a crafting table, and then placing prismarine crystals in every other square.",
    "cookie": "A cookie can be crafted by placing wheat, horizontally, on both sides of cocoa beans in a crafting table.",
    "melon seeds": "Melon seeds can be crafted by placing a slice of melon in a crafting window.",
    "gold nugget": "A gold nugget can be crafted by placing a single gold ingot into a crafting window. They can also be randomly obtained by killing a zombie pig men.",
    "red stone ore block": "Redstone ore can be found in the bottom sixteen layers on the map. If broken with an iron pick ax or better, it will drop some amount of red stone. To obtain the ore itself, one would need to use a pick ax with a silk touch enchant.",
    "diamond helmet": "All helmets are crafted by placing the desired material in all squares but the very center square and the bottom row in a crafting table.",
    "spruce fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "golden hoe": "All types of hoes can be crafted by placing two of the desired material in the top left, and top middle squares, with sticks in the center and bottom middle squares in a crafting table.",
    "acacia wood plank": "Acacia wood planks can be obtained by placing acacia wood in a crafting table",
    "diamond pick ax": "All types of pick axes can be crafted by placing three of the desired material across the top row, and then placing sticks in the center and bottom middle squares in a crafting table.",
    "lapis lazuli ore": "Lapis Lazuli Ore can be only be obtained by using a pick ax with the silk touch enchant.",
    "raw mutton": "Raw mutton can be obtained by killing a sheep.",
    "quartz stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "brick block": "A brick block can be crafted by placing clay bricks in a two by two grid in a crafting window.",
    "cobblestone slab": "A cobblestone slab can be crafted by placing three cobblestone blocks in a row in a crafting table.",
    "emerald ore": "Emerald ore can only be found in extreme hills biomes between layers four and thirty-two. It can be mined with an iron pick ax or better to obtain an emerald. To obtain the ore itself, you will need a silk touch pick ax.",
    "yellow flower": "Dandelions can be found naturally on grass or created randomly by using bone meal on grass.",
    "jack o'lantern": "A jack o'lantern can be crafted by placing a pumpkin on top of a torch in a crafting table.",
    "red stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "iron leggings": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "pink stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "black dye": "An ink sack is used as black dye in mine craft.",
    "wooden hoe": "All types of hoes can be crafted by placing two of the desired material in the top left, and top middle squares, with sticks in the center and bottom middle squares in a crafting table.",
    "purple stained glass": "Any type of stained glass can be crafted by placing the desired color dye in the center square, and glass surrounding that.",
    "mine cart with chest": "A mine cart with a chest is crafted by placing a chest on top of a mine cart in a crafting window.",
    "detector rail": "A detector rail can be crafted by placing a stone pressure plate in the very center square, red stone in the bottom middle square, and iron ingots in the far left and far right columns",
    "cyan wool": "Cyan wool can be crafted by placing cyan dye next to any color wool in a crafting window.",
    "iron chestplate": "All chestplates are crafted by placing the desired material in all squares but the top middle square in a crafting table.",
    "cobblestone": "Cobblestone can be obtained by breaking stone with a pick ax.",
    "dark oak wood stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares.",
    "creeper mob head": "Mob heads can be obtained by having a charged creeper blow up the mob whose head you want to obtain.",
    "carrot": "Carrots can be rarely obtained by killing zombies or, they can be naturally found as crops in villages.",
    "rabbit hide": "Rabbit hide can be randomly obtained by killing a rabbit.",
    "grass": "When harvested with a regular shovel, grass turns into dirt. In order to obtain a grass block you will need to have a shovel with the silk touch enchant.",
    "strad disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "birch sapling": "Birch saplings can be randomly obtained by breaking birch leaves.",
    "mossy stone": "Mossy stone can be crafted by placing vines next to cobblestone in a crafting table. It can also be found naturally in various dungeons.",
    "pink dye": "Pink dye can be crafted by placing bone meal next to rose red in a crafting window.",
    "red stone torch": "A red stone torch is crafted by placing red stone on top of a torch in a crafting window.",
    "green stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "tall grass": "Tall grass, which is called grass in a players inventory, spawns on grass blacks in certain biomes. Bonemeal can be used on a grass block to grow tall grass and occasionally flowers.",
    "black wool": "Black wool can be crafted by placing an ink sac next to any color wool in a crafting window.",
    "wheat crops": "Wheat can be found naturally in villages or can be grown from seeds that one can obtain by breaking tall grass.",
    "ender pearl": "Ender pearls can be randomly obtained by killing ender men.",
    "moss stone": "Moss stone can be crafted by placing vines next to cobblestone in a crafting table. It can also be found naturally in various dungeons.",
    "fishing rod": "A fishing rod is crafted by placing three sticks in a diagonal line, and then two string beneath the top right stick in a crafting window.",
    "bone meal": "Bone meal can be crafted by placing a bone into a crafting window.",
    "quartz": "Nether Quartz can be obtained by smelting Nether Quartz Ore in a furnace.",
    "dark oak wood plank": "Dark oak wood planks can be obtained by placing dark oak wood in a crafting table.",
    "powered rail": "A powered rail can be crafted by placing a stick in the very center square, red stone in the bottom middle square, and gold ingots in the far left and far right columns",
    "beacon": "A beacon can be obtained by placing a nether star in the very center square, three obsidian across the bottom row, and five glass in the remaining squares in a crafting table.",
    "blue stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "dark oak door": "A Dark Oak Door can be crafted by placing six Dark Oak Planks down the first two columns.",
    "iron golem": "An iron golem can be created by similarly to a snow golem. Place a pumpkin head on top of two iron blocks. Then place two more iron blocks on either side of the very center iron block.",
    "spruce wood": "All types of wood can be obtained by breaking the tree they naturally grow into.",
    "pink wool": "Pink wool can be crafted by placing pink dye next to any color wool in a crafting window.",
    "fire charge": "A fire charge can be crafted by placing blaze powder in the middle left square, coal in the very center square, and gunpowder in the bottom middle square in a crafting table.",
    "acacia door": "An Acacia Door can be crafted by placing six Acacia Planks down the first two columns.",
    "iron pants": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "chirp disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "oak leaves": "All leaves can be obtained by using a shear on the desired leaf.",
    "arrow": "An arrow can be crafted by placing flint in the top middle square, a stick in the very center square, and a feather in the bottom middle square in a crafting table.",
    "wooden ax": "All types of axes can be crafted by placing three of the desired material in the top left, top middle, and middle left squares, with sticks in the center and bottom middle squares in a crafting table.",
    "glass pane": "A glass pane can be crafted by placing six glass blocks across the bottom two rows in a crafting table.",
    "gold helmet": "All helmets are crafted by placing the desired material in all squares but the very center square and the bottom row in a crafting table.",
    "ender chest": "An ender chest can be crafted by placing an eye of ender in the center square, and then surrounding that with eight obsidian blocks in a crafting table.",
    "light blue wool": "Light blue wool can be crafted by placing light blue dye next to any color wool in a crafting window.",
    "string": "String can be randomly obtained by killing spiders or by breaking cobwebs.",
    "red sandstone stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "purple wool": "Purple wool can be crafted by placing purple dye next to any color wool in a crafting window.",
    "cyan stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows.",
    "black stained clay": "Any type of stained clay can be crafted by placing the appropriate dye in the center square and hardened clay surrounding it.",
    "enchanted book": "Enchanted books can be found in chests located in dungeons, strongholds, desert temples, jungle temples, and mine shafts.",
    "button": "A button can be crafted by placing either a single piece of smooth stone or a single wooden plank in a crafting window.",
    "lime wool": "Lime wool can be crafted by placing lime dye next to any color wool in a crafting window.",
    "coarse dirt": "Coarse dirt can be obtained by breaking dirt in the Mega Taiga, Mesa, or Savanna biomes.",
    "ghast tear": "Ghast tears can be rarely obtained by killing ghasts.",
    "mine cart with a furnace": "A mine cart with a furnace is crafted by placing a furnace on top of a mine cart in a crafting window.",
    "wheat": "Wheat can be found naturally in villages or can be grown from seeds that one can obtain by breaking tall grass.",
    "soul sand": "Soul sand can be found commonly throughout the Nether dimension.",
    "brown mushroom": "Brown mushrooms can be found naturally in darkly lit areas, mushroom biomes, or the nether.",
    "chainmail helmet": "Chainmail armor can only be obtained by trading with a villager or getting a rare drop off of a mob.",
    "written book": "A written book is created after a book and quill is signed.",
    "spruce sapling": "Spruce saplings can be randomly obtained by breaking spruce leaves.",
    "oak sapling": "Oak saplings can be randomly obtained by breaking oak leaves.",
    "inverted daylight sensor": "An inverted daylight sensor can be created by right clicking on a daylight sensor.",
    "sandstone stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "red stone lamp": "A red stone lamp can be crafted by placing glow stone in the very center square, and surrounding it with four red stone in a crafting table.",
    "crafting table": "A crafting table is crafted by placing wooden planks in a two by two grid in a crafting window.",
    "glow stone": "Glow stone can be found on the ceiling in the Nether dimension.",
    "wooden pressure plate": "A wooden pressure plate can be created by placing two wooden planks, horizontally, next to each other in a crafting window.",
    "charcoal": "Charcoal can be obtained by burning wood blocks in a furnace.",
    "chainmail boots": "Chainmail armor can only be obtained by trading with a villager or getting a rare drop off of a mob.",
    "ladder": "A ladder is crafted by placing sticks in every square but the top middle and bottom middle square.",
    "mossy cobblestone": "Mossy cobblestone can be crafted by placing vines next to cobblestone in a crafting table. It can also be found naturally in various dungeons.",
    "golden pick ax": "All types of pick axes can be crafted by placing three of the desired material across the top row, and then placing sticks in the center and bottom middle squares in a crafting table.",
    "seeds": "Wheat seeds can be randomly found by breaking tall grass.",
    "acacia fence gate": "Any type of fence gate can be crafted by placing a stick, a wooden plank, and then another stick across the bottom two rows in a crafting table.",
    "birch wood stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "ward disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "music disc": "A random music disc has a possibility of dropping when a Skeleton's Arrow kills a Creeper. Alternately, music disc are found in eight percent of dungeon chest.",
    "enchanted golden apple": "An enchanted golden apple is crafted by placing an apple in the very center square and surrounding it with eight gold blocks.",
    "white carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "iron sword": "All types of swords can be crafted by placing the desired material in the top middle and very center square, with a stick beneath them, in a crafting table",
    "diamonds pants": "All leggings are crafted by placing the desired material in all squares but the center square and bottom middle square in a crafting table.",
    "chiseled red sandstone": "Chiseled red sandstone can be crafted by placing a red sandstone slab on top of a red sandstone slab in a crafting window.",
    "stone brick stairs": "All types of stairs can be crafted by placing the desired material in all squares but the top middle, top right, and middle right squares in a crafting table.",
    "pressure plate": "A pressure plate can be created by placing either two smooth stone or two wooden planks next to each other, horizontally, in a crafting window.",
    "jungle wood plank": "Jungle wood planks can be obtained by placing jungle wood in a crafting table",
    "green wool": "Green wool can be crafted by placing cactus green next to any color wool in a crafting window.",
    "sugar canes": "Sugar canes occur naturally near water.",
    "bow": "A bow can be crafted by placing three string in the rightmost column and then placing tree sticks in a less than sign pattern next to the string in a crafting table.",
    "lime carpet": "Any type of carpet can be crafted by placing two wool, of the same color, next to each other in a crafting window.",
    "flint": "Flint is randomly dropped while breaking gravel.",
    "black stained glass pane": "Any type of stained glass pane can be crafted by placing the same color stained glass, horizontally, in the bottom two rows."
};
*/
